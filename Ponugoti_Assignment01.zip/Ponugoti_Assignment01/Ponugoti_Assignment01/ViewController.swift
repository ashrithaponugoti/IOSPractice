//
//  ViewController.swift
//  Ponugoti_Assignment01
//
//  Created by Ponugoti,Ashritha on 1/31/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

