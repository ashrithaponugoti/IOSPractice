//
//  ResultViewController.swift
//  Ponugoti_MVC
//
//  Created by Ashritha Ponugoti on 4/2/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var firstNameLabel: UILabel!
    
    
    @IBOutlet weak var lastNameLabel: UILabel!
    
    
    @IBOutlet weak var sidLabel: UILabel!
    
    
    
    @IBOutlet weak var northwestIDLabel: UILabel!
    
    var destinationFirstName = ""
    var destinationLastName = ""
    var destinationSID = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        firstNameLabel.text = "First Name : \(destinationFirstName)"
        lastNameLabel.text = "Last Name : \(destinationLastName)"
        sidLabel.text = "SID : \(destinationSID)"
        northwestIDLabel.text = "Your Northwest ID is \(destinationSID)@nwmissouri.edu"
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
