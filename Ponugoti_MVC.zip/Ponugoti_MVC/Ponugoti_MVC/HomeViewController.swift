//
//  ViewController.swift
//  Ponugoti_MVC
//
//  Created by Ashritha Ponugoti on 4/2/23.
//

import UIKit

class HomeViewController: UIViewController {

    
    @IBOutlet weak var firstNameOL: UITextField!
    
    
    @IBOutlet weak var lastNameOL: UITextField!
    
    
    @IBOutlet weak var sidOL: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func submitBtn(_ sender: UIButton) {
        var fn = firstNameOL.text!
        var ln = lastNameOL.text!
        var sid = sidOL.text!
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "resultSegue"{
            var destination = segue.destination as! ResultViewController
            destination.destinationFirstName = firstNameOL.text!
            destination.destinationLastName = lastNameOL.text!
            destination.destinationSID = sidOL.text!
        }
    }
    

}

