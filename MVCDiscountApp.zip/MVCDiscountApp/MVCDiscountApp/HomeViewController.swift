//
//  ViewController.swift
//  MVCDiscountApp
//
//  Created by Ponugoti,Ashritha on 3/30/23.
//

import UIKit

class HomeViewController: UIViewController {

    var priceAfterDiscount = 0.0
    
    @IBOutlet weak var AmountOL: UITextField!
    
    @IBOutlet weak var DiscountOL: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func BtnClicked(_ sender: UIButton) {
        
        var amount = Double(AmountOL.text!)!
        print(amount)
        var disRate = Double(DiscountOL.text!)!
        print(disRate)
        priceAfterDiscount = amount - (disRate*amount/100)
        print(priceAfterDiscount)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "resultSegue"{
            var destination = segue.destination as! ResultViewController
            //Assign values to result view controller
            destination.destinationAmount = AmountOL.text!
            destination.destinationDiscRate = DiscountOL.text!
            destination.result = String(priceAfterDiscount)
        }
    }
}

