//
//  ViewController.swift
//  CourseApp
//
//  Created by Chintala,Rajitha on 4/11/23.
//

import UIKit

class LoginViewController: UIViewController {
    
    var courseFound=CourseDetails()
    var isCourse = false
    var Courses = CoursesArray
    
    @IBOutlet weak var courseIDOL: UITextField!
    @IBOutlet weak var studentSIDOL: UITextField!
    
    @IBOutlet weak var enrollOL: UIButton!
    @IBOutlet weak var courseStatus: UILabel!
    @IBOutlet weak var imageViewOL: UIImageView!
    @IBOutlet weak var courseCheckbtnOL: UIButton!
    @IBAction func CourseIDAction(_ sender: Any) {
        if(courseIDOL.text != ""){
        courseCheckbtnOL.isEnabled = true
        }else if(courseIDOL.text == ""){
            courseCheckbtnOL.isEnabled = false
        }
    }
    
    @IBAction func courseCheckBtn(_ sender: Any) {
        let courseID = courseIDOL.text!
        for course in CoursesArray{
            if courseID == course.courseID{
                isCourse = true
                courseFound = course
                break
            }
            else{
                isCourse = false
            }
        }
        if isCourse{
            imageViewOL.image = UIImage(named: courseFound.courseImage)
            courseStatus.text = courseFound.courseName+" is open for Registration"
            enrollOL.isHidden = false
        }else{
            imageViewOL.image = UIImage(named: "default")
            courseStatus.text = "Course Id not found"
            enrollOL.isHidden = true
        }
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        courseCheckbtnOL.isEnabled = false
    enrollOL.isHidden = true
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "courseSegue"{
            let destination = segue.destination as! ResultViewController
            destination.course = courseFound
            destination.sID = studentSIDOL.text!
            
        }
    }

}

