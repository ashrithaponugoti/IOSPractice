//
//  ResultViewController.swift
//  CourseApp
//
//  Created by Chintala,Rajitha on 4/11/23.
//

import UIKit

class ResultViewController: UIViewController {

    var course = CourseDetails()
   var sID = ""
   @IBOutlet weak var studentLabel: UILabel!
   @IBOutlet weak var placeHolderOL: UILabel!
   @IBOutlet weak var imageViewCourseOL: UIImageView!
   
   
   override func viewDidLoad() {
       super.viewDidLoad()
       
       imageViewCourseOL.image = UIImage(named: course.courseImage)
       shake(course.courseImage)
       studentLabel.text = studentLabel.text!+sID
       placeHolderOL.text = placeHolderOL.text!+course.courseID+", "+course.courseName
       
       // Do any additional setup after loading the view.
   }
   
   
   func shake(_ image: String) {
       var width = imageViewCourseOL.frame.width
       
       width += 40
       
       var height = imageViewCourseOL.frame.height
       
       height = height + 40
       
       var x  =  imageViewCourseOL.frame.origin.x-20
       
       
       var y = imageViewCourseOL.frame.origin.y-20
       
       var largeFrame = CGRect(x: x, y: y, width: width, height: height)
       
       UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
           self.imageViewCourseOL.frame = largeFrame
       })
       
   }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
