//
//  ViewController.swift
//  Ponugoti_Exam01
//
//  Created by Ponugoti,Ashritha on 2/28/23.
//

import UIKit

class ViewController: UIViewController {
    
 
    
    
    @IBOutlet weak var labelOL: UILabel!
    
    
    @IBOutlet weak var inputOL: UITextField!
    
    
    @IBOutlet weak var imageOL: UIImageView!
    
    
    @IBOutlet weak var label2OL: UILabel!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        imageOL.image=UIImage(named: "default")
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func USDButton(_ sender: UIButton) {
        
        if inputOL.text==""{
            label2OL.text="Please enter some Amount"
            imageOL.image=UIImage(named: "oops")
        }
        else{
            var amount = Double(inputOL.text!)!
            if amount==0{
                label2OL.text="₹ \(amount) Oops! cannot convert"
                imageOL.image=UIImage(named: "oops")
            }
            else{
                var usd=amount/82.93
                var res=round(usd*100)/100
                label2OL.text="₹ \(amount) in USD is: $\(res)"
                imageOL.image=UIImage(named: "usd")
            }
        }
        
        
    }
    
    
    @IBAction func CADButton(_ sender: UIButton) {
        
        if inputOL.text==""{
            label2OL.text="Please enter some Amount"
            imageOL.image=UIImage(named: "oops")
        }
        else{
            var amount = Double(inputOL.text!)!
            if amount==0{
                label2OL.text="₹ \(amount) Oops! cannot convert"
                imageOL.image=UIImage(named: "oops")
            }
            else{
                //var us=amount/82.93
                var cad=(amount*1.26)/82.93
                var res1=round(cad*100)/100
                label2OL.text="₹ \(amount) in CAD is: $\(res1)"
                imageOL.image=UIImage(named: "cad")
            }
        }
        
    }
    

}

