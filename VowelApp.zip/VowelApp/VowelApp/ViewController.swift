//
//  ViewController.swift
//  VowelApp
//
//  Created by Ponugoti,Ashritha on 1/31/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var inputOutlet: UITextField!
    
    
    @IBOutlet weak var labelOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonClicked(_ sender: UIButton) {
        //Reading the input text
        var input=inputOutlet.text!
        var name=input.lowercased()
        if name.contains("a") || name.contains("e") || name.contains("i") || name.contains("o") || name.contains("u"){
            labelOutlet.text="The entered text has vowels🙂"
        }
        else{
            labelOutlet.text="The entered text has no vowels☹️"
        }
            
    }
    
}

