//
//  ViewController.swift
//  HelloApp
//
//  Created by Ponugoti,Ashritha on 1/24/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var inputOutlet: UITextField!
    
    
    @IBOutlet weak var displayLabelOutlet: UILabel!
    
    
    @IBOutlet weak var input2Outlet: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitButtonClicked(_ sender: UIButton) {
        //Read the input from the text field and store it in a variable
        var input=inputOutlet.text!
        var input2=input2Outlet.text!
        //Perform the string interpolation and assign it to display label
        displayLabelOutlet.text="Hello,\(input) \(input2)😎!"
        
        
        
    }
    
}

