//
//  ResultViewController.swift
//  SampleBMI
//
//  Created by Ashritha Ponugoti on 4/10/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var labelOL: UILabel!
    
    
    @IBOutlet weak var imageOL: UIImageView!
    
    var BMI = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        labelOL.text = BMI
        var b = Double(BMI)!
        if b<18.5{
            updateAndAnimate("uw")
        }
        else if b>=18.5 && b<25{
            updateAndAnimate("nw")
        }
        else {
            updateAndAnimate("ow")
        }
        
        // Do any additional setup after loading the view.
    }
    func updateAndAnimate(_ imageName : String){
            
            //making the current image opaque.
            UIView.animate(withDuration: 1, animations: {
                self.imageOL.alpha = 0
            })
            
            //Assign the new image with animation and make it transparent. (alpha = 1)
            
            UIView.animate(withDuration: 1, delay:0.5, animations: {
                self.imageOL.alpha = 1
                self.imageOL.image = UIImage(named: imageName)
            })
            

        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
