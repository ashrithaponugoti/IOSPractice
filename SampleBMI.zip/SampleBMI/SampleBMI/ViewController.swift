//
//  ViewController.swift
//  SampleBMI
//
//  Created by Ashritha Ponugoti on 4/10/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var heightOL: UITextField!
    
    
    @IBOutlet weak var weightOL: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    var height = 0.0
    var weight = 0.0
    var bmi = 0.0
   
    
    @IBAction func BMIBtn(_ sender: UIButton) {
        
        height = Double(heightOL.text!)!
        weight = Double(weightOL.text!)!
        var rbmi = weight/(height*height)
        bmi = (rbmi * 100)/100
        
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition=="resultSegue"{
            var destination = segue.destination as! ResultViewController
            destination.BMI = String(bmi)
            
            
            
        }
    }
    
    
}

