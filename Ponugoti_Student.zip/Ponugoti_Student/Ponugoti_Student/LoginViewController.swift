//
//  ViewController.swift
//  Ponugoti_Student
//
//  Created by Ponugoti,Ashritha on 4/4/23.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var sIdOutlet: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    


}

