//
//  Student.swift
//  Ponugoti_Student
//
//  Created by Ponugoti,Ashritha on 4/4/23.
//

import Foundation

struct Student{
    var name = ""
    var sid = ""
    var email = ""
    var courses:[Course] = []
}

struct Course{
    var title = ""
    var sem = ""
}

let student1 = Student(name:"Adam",sid:"s12345",email: "s12345@gmail.com",courses: [Course(title:"Mobile Computing",sem:"sp21"),Course(title:"Big Data",sem:"sp22")])
