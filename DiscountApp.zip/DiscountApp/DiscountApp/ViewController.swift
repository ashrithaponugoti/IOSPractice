//
//  ViewController.swift
//  DiscountApp
//
//  Created by Ponugoti,Ashritha on 2/14/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var amountOutlet: UITextField!
    
    
    @IBOutlet weak var discountOutlet: UITextField!
    
    
    @IBOutlet weak var displayOutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func buttonClicked(_ sender: UIButton) {
        var amount=Double(amountOutlet.text!)!
        var discount=Double(discountOutlet.text!)!
        
        
        var discPrice=amount-((discount/100)*amount)
        
        displayOutlet.text="Price after discount: $\(discPrice)"
    }
    

}

